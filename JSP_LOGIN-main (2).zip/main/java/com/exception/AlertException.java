package com.exception;

public class AlertException extends Exception {
	public AlertException(String message) {
		super(message);
	}
}
