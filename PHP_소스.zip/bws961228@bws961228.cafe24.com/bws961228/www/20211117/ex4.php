<form method="post" action="ex3_process.php?t1=1&t2=2">
	아이디 <input type="text" name="memId"><br>
	비밀번호 <input type="password" name="memPw"><br>
	<input type="submit" value="POST 로그인!">
</form>

<form method="get" action="ex3_process.php">
	아이디 <input type="text" name="memId"><br>
	비밀번호 <input type="password" name="memPw"><br>
	<input type="submit" value="GET 로그인!">
</form>