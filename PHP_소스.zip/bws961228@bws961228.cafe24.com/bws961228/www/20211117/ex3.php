<?php

// 지역 : locall, 전역 : global
$num3 = 10;	// 전역변수
function sum($num1, $num2) {	// num1, num2 == 지역변수
	//global $num3; // 전역변수 불러올 때 global 사용
	echo"<pre>";
	//print_r($_GLOBALS); // ($_명칭) - (초 전역변수) -> 전역변수의 한계를 넘음 - > 전역변수의 값이 담겨있음
	
	$result = $num1 + $num2 + $GLOBALS['num3'];
	
	return $result;
}

print sum(10,20);