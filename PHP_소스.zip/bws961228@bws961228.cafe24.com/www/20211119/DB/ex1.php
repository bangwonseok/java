<?php
//echo $_SERVER['REMOTE_ADDR'];
try{
	$dsn = "mysql:host=localhost;port=3306;dbname=bws961228"; // port=3306; 생략 가능(기본포트임)
	$username = "bws961228";
	$password = "walkmouse3!@";
	$db = new PDO($dsn, $username, $password);
	
	$sql = "INSERT INTO member (memId, memPw, memNm)
				VALUES('abcde', '12345', '이름')";
	$affectedRows = $db->exec($sql);
	echo $affectedRows;
} catch(PDOException $e){
	echo $e -> getMessage();
}