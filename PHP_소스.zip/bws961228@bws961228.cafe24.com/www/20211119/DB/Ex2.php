<?php
try{
	$dsn = "mysql:host=localhost;dbname=bws961228";
	$username = "bws961228";
	$password = "walkmouse3!@";
	$db = new PDO($dsn, $username, $password);
	$sql = "SELECT *FROM member";
	$stmt = $db -> query($sql);	// 변수 이름 임의로 정한듯
	//while($koss = $stmt -> fetch(PDO::FETCH_ASSOC)){
//		while($koss = $stmt -> fetch(PDO::FETCH_NUM)){
	while($koss = $stmt -> fetch(PDO::FETCH_BOTH)){
		echo"<pre>";
		print_r($koss); // 변수 이름 임의로 정함
		echo"<pre>";
	}
} catch(PDOExcetpion $e){
	echo $e->getMessage();
}