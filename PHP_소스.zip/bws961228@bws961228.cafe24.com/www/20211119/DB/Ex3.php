<?php

try{
	$dsn = "mysql:host=localhost;dbname=bws961228";
	$username = "bws961228";
	$password = "walkmouse3!@";
	$db = new PDO($dsn, $username, $password);
	$sql = "INSERT INTO member (memId, memPw, memNm)
				VALUES(:memId, :memPw, :memNm)";
	

	
	$stmt = $db->prepare($sql);
	$stmt->bindValue(":memId", "abc333");
	$stmt->bindValue(":memPw", "def");
	$stmt->bindValue(":memNm", "ghi");
	$result = $stmt->execute();
	echo $result;
	
} catch(PDOException $e){
	echo $e->getMessage();
}