<?php

class A{
	const NUM1 = 10;	// == public static final, (:: 으로 접근)
	public $num2 = 20; // 생성한 이후 접근 아래 인스턴스
	
	public function method() { // 상수 접근, const == 상수
		self::NUM1;
	}
}

echo A::NUM1;
echo "<br>";
$a = new A();
echo $a->num2;