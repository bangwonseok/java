<?php

abstract class AbstractA{
	public $B =20;
	public abstract function sum($num1, $num2);
	
	public function Method(){
		echo "공통 메서드";
	}
}

class A extends AbstractA{
	public function sum($num1, $num2){
		echo $this->B ."<br>";
		echo $this->Method()."<br>";
		return $num1 + $num2;
	}
}

$a = new A();
echo $a ->sum(20,30) ."<br>";
