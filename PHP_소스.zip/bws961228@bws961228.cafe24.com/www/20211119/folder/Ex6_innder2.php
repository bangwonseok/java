<h1>추가된 내용2 ...</h1>
<?php
include "../Ex6_inner.php";