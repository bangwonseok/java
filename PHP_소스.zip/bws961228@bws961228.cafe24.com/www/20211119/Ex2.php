<?php
class A{
	public $numA= 10;
	public function wsA(){
		echo "안녕하세요";
	}
}

class B extends A{
	public function wsA(){
		parent::wsA(); // super과 동일
		echo "안녕안헤요ㅜㅜ B";
		echo $this->numA;
	}
}

$b= new B();
echo $b->numA . "<br>";
echo $b -> wsA();

/*** **/
echo "<br>";
echo $b instanceof A;
echo "<br>";
echo $b instanceof B;