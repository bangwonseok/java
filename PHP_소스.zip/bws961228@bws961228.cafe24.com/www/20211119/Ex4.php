<?php

interface InterA{
	public function methodA(); // == public abstract function methodA();
	public function method();
}

interface InterB{
	public function methodB();
	public function method();
}

class A implements InterA, InterB{
	public function methodA(){
		echo "인터페이스A 메서드";
	}
	
	public function methodB(){
		echo "인터페이스 B 메서드";
	}
	
	public function method(){
		echo "인터페이스 메서드";
	}
}