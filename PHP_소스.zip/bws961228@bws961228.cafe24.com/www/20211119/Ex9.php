<?php
include_once"Ex5.php";
include_once"Ex5.php";
include_once"Ex5.php";
