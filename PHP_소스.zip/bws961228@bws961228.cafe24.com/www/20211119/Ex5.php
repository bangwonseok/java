<?php

interface InterA{
	public function methodA();
	public function method();
}

interface InterB{
	public function methodB();
	public function method();
}

interface InterC extends InterA, InterB{
	public function methodC();
}

class A implements InterC{
	public function methodA(){
		echo "안녕";
	}
	public function methodB(){
		
	}
	
	public function methodC(){
		
	}
	
	public function method(){
		
	}
}
$a = new A();
echo $a -> methodA ;

