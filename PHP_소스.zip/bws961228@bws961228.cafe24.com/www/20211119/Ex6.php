<?php

include "Ex6_inner.php"; // 상대 경로
include "folder/Ex6_innder2.php";

include __DIR__  ."../Ex6_inner.php"; // 상대 경로

echo __DIR__ ."<br>";// 절대 경로 ex.)http://home/web/
echo __FILE__; // 파일 위치 ex.)http://home/web/Ex6.php
