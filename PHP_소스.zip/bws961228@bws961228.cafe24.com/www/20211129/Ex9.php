<?php
$params = [
	'key1' = > '값1';
	'key2' = > '값2';
];
$handle = curl_init();
curl_setopt($handle, CURLOPT
curl_setopt($handle,,,..);