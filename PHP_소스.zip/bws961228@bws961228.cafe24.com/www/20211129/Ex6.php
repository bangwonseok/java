<?php
$data = file_get_contents("data4.txt");
echo $data;