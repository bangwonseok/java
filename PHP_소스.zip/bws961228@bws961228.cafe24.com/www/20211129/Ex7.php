<?php
echo file_put_contents("data3.txt", "텍스트1 텍스트2 텍스트3");