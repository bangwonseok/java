<?php
echo "<img src='image/rank/rank{$_GET['num']}.png'>";