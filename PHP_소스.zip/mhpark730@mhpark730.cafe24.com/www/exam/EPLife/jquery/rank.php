<script>
$(() => {
	$(".team_rank").click(function() {
		$.ajax({
			url : "team_rank.php",
			type : "get",
			dataType : "html",
			success : function(res) {
				$(".output").html(res);
			},
			error : function(err) {
				console.error(err);
			}
		});
	});
});
</script>