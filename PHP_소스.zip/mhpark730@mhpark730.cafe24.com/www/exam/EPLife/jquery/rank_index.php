<script>
$(() => {
	$(".team_rank li").click(function() {
		
		
		$.ajax({
			url : "team_rank.php",
			type : "get",
			dataType : "html",
			data : { num : num },
			success : function(data) {
				$(".output").html(data);
			},
			error : function(err) {
				console.error(err);
			}
		});
	});
});
</script>