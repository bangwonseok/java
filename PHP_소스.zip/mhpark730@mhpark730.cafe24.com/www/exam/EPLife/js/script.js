window.addEventListener("DOMContentLoaded", function(e) {
var swiper = new Swiper('.swiper-container', {
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
	  loop: true,
	  speed: 1000,
	  autoplay: {
		  delay: 3000,
	  },
	  
	    pagination: {
        el: '.swiper-pagination',
		
		clickable: true,
      },
    });
}, false);