<?php
echo "<img src='../img/goods{$_GET['num']}.jpg'>";