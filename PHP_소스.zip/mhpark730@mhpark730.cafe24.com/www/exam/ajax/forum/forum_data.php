<?php
header("Content-type", "application/json; charset=utf-8");
$list = [
	"영국 ‘맨체스터 이브닝 뉴스’에 따르면 맨유는",
	"낙점했다. 당시 맨유는 로멜루 루카쿠가 인터",
	"올레 군나르 솔샤르 감독은 새로운 공격수 영입으로",
	"솔샤르 감독과 홀란드는 같은 노르웨이",
	"하지만 홀란드는 잘츠부르크로 이적했고",
];

echo json_encode($list);