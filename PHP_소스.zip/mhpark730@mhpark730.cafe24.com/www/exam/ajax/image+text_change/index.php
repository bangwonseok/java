<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		<script>
			$(() => {
				$(".post").click(function() {
					const num = $(this).data("num");
					//const url = `post/${num}.php`;
					const url = "images.php";
					
					$.ajax({
						url : url, 
						type : "get",
						dataType : "json",
						data : { num : num },
						success : function(res) {
							const image = `<img src="${res.imageSrc}">`;
							$("#text").text(res.text);
							$("#image").html(image);
							//$("#output").html(res);
							//res = JSON.parse(res);
							// <-> JSON.stringify
						},
						error : function(err) {
							console.error(err);
						}
					});
				});
			});
		</script>
	</head>
	<body>
		<div>
			<span class="post" data-num='1'>글1</span>
			<span class="post" data-num='2'>글2</span>
			<span class="post" data-num='3'>글3</span>
		</div>
		<div id="output">
			<div id="text"></div>
			<div id="image"></div>
		</div> <!-- 원격 페이지 내용을 출력 -->
	</body>
</html>