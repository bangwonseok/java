<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		<script>
			$(() => {
				$(".post").click(function() {
					const num = $(this).data("num");
					console.log(num);
					
					$.ajax({
						url : "ajax_html.php",
						type : "get",
						dataType : "html",
						data : { num : num },
						success : function(data) {
							$("#image").html(data);
						},
						error : function(err) {
							console.error(err);
						}
					});
				});
			});
			
					
		</script>
		
	</head>
	<body>
		<div>
			<span class="post" data-num="1">1번</span>
			<span class="post" data-num="2">2번</span>
			<span class="post" data-num="3">3번</span>
		</div>
		
		<div id="image"></div>
	</body>
</html>