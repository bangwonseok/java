<?php
echo "<img src='post/img/goods{$_GET['num']}.jpg'>";