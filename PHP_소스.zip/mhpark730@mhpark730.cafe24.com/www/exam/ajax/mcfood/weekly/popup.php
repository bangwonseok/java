<?php

echo "<h1>".$_GET['num']." 상품 상세 정보<h1>";