<?php
echo "<img src='goods{$_GET['num']}.jpg'>";