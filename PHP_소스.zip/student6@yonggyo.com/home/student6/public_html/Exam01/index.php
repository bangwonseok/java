<?php 
include "_common.php";
include "Outline/_header.php";
?>
<a href='member/join.php'>회원가입</a>
<a href='member/login.php'>로그인</a>
<?php
include "Outline/_footer.php";