export default {
    created() {
        this.$loginInit();
    }
}