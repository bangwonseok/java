<template>
<h1 class='page_title'><slot></slot></h1>
</template>