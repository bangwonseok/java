<?php
interface InterA {
	public function methodA();
}