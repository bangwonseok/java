<?php 
include "Ex8.php";  // warning  -> PHP 스크립트의 중단 하지 않고 경고 표기 

//require "Ex8.php"; // error -> PHP 스크립트를 중단하고 오류 표기 

echo "<h1>출력되나요?</h1>";