<?php
session_start();
$_SESSION['key1'] = '값1';
$_SESSION['key2'] = '값2';