<?php
trait traitB {
	
	public function methodB() {
		echo "methodB<br>";
	}
}