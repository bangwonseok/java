<?php
trait traitA {
	public $numA = 10;
	
	public function method() {
		
	}
	
	public function methodA() {
		echo "methodA";
	}
}