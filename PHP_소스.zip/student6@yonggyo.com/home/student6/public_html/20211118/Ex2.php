<form method="post" action="Ex2_process.php" enctype="multipart/form-data">
	<input type="file" name="file">
	<input type="submit" value="업로드">
</form>