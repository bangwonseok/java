<?php
$school = "연희직업전문학교";

$a = 'school';
echo $$a; // $$a == $school 


echo "<be>";
define("NUM1", 10);
echo NUM1;
