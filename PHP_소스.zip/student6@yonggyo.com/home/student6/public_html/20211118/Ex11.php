<?php


$sum = function ($num1, $num2) {
	
	return $num1 + $num2;
};

echo $sum(10, 20);

//echo $sum instanceof Closure;