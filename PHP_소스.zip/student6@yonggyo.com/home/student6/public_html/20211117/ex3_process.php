<?php
echo "<pre>";
print_r($_SERVER);
echo "</pre>";

echo "<h1>POST</h1>";
echo "<pre>";
print_r($_POST);
echo "</pre>";

echo "<h1>GET</h1>";
echo "<pre>";
print_r($_GET);
echo "</pre>";

echo "<h1>REQUEST</h1>";
echo "<pre>";
print_r($_REQUEST);
echo "</pre>";