package com.models.category;

public class Category {

}
