package com.models.goods;

import java.util.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.*;
import static com.core.DB.setBinding;

import org.mindrot.jbcrypt.*;
import com.core.DB;
import com.core.DBField;
import com.core.Logger;
import com.core.Req;
import com.models.member.Member;
import com.models.member.MemberDao;
import com.models.snslogin.*;


public class GoodsDao {
	private static GoodsDao instance = new GoodsDao();
	private static Goods socialMember;
	
	private GoodsDao() {};  // 기본 생성자 private -> 외부 생성 X, 내부에서만 생성 O
	
	public static GoodsDao getInstance() {
		if (instance == null) {
			instance = new GoodsDao();
		}
			
		return instance;
	}
	
	/**
	 * 상품 추가
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public boolean addGoods(HttpServletRequest request) throws Exception {
		

		
		ArrayList<DBField> bindings = new ArrayList<>();
		String sql = "INSERT INTO goods (goodsImage, goodsNm, goodsPrice, goodsCategory, goodsExplain) VALUES (?,?,?,?,?)";
		String goodsImage = "";
		String goodsNm = "";
		String goodsPrice = "";
		String goodsCategory = "";
		String goodsExplain = "";
		
		bindings.add(setBinding("Blob", goodsImage));
		bindings.add(setBinding("String", goodsNm));
		bindings.add(setBinding("String", goodsPrice));
		bindings.add(setBinding("String", goodsCategory));
		bindings.add(setBinding("String", goodsExplain));
		
		
		int rs = DB.executeUpdate(sql, bindings);
		
		return (rs > 0)?true:false;
		}
		
	
	
	
	/**
	 * 삼품 조회
	 * 
	 * @param goodsNo
	 * @return
	 */
	public Member getMember(int goodsNo) {
		
		String sql = "SELECT a.*, b.memId, b.memN  FROM goods a LEFT JOIN member b on ";
		ArrayList<DBField> bindings = new ArrayList<>();
		
	
		
		return null;
	}
}