// 현 파일명을 포함한 전체 경로(_ X 2)
console.log("__filename", __filename);

// 현 디렉토리 경로(_ X 2)
console.log("__dirname", __dirname);