$(function(){
	alert("방원석방방원석")
});