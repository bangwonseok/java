package com.model.dao;

/**
 * 다음 페이지 5개 나오는법
 */

import java.util.*;
import java.sql.*;
import com.core.*;
import com.model.dto.Board;

public class Board2DAO {	// 다음 5개 추가, test-> list.jsp도 시험관련
	
	public ArrayList<Board>getList(){
		return getList(1, 5);
	}
	
	public ArrayList<Board>getList(int page){
		return getList(page, 5);
	}
	
	/**
	 * 
	 * @param page 페이지 번호
	 * 				예) 한 페이지당 글의 개수 5개
	 * 				1 페이지 : 1~5
	 * 				2 페이지 : 6~10
	 * 				3 페이지 : 10~15
	 * @param limit
	 * @return
	 */
	public ArrayList<Board> getList(int page, int limit){
		ArrayList<Board> list = new ArrayList<>();
		
		/**
		 *  LIMIT 숫자 (시작 지점), 숫자(투플의 갯수)
		 *  LIMIT 숫자 (투플의 갯수) == LIMIT 0, 숫자(투플의 갯수)
		 */
		
		/**
		page 1번 : 0번부터 (0, 1, 2, 3, 4)
		page 2번 : 5번부터 (5, 6, 7, 8, 9)
		*/
		page = (page<=0)?1:page;
		limit = (limit <=0)?5:limit;
		
		int offset =(page -1) * limit;
		
		String sql = "SELECT * FROM board ORDER BY DESC LIMIT ?, ?";
		try(Connection conn = DB.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)){
				pstmt.setInt(1, offset);
				pstmt.setInt(2, limit);
				
				/**
				 * SELECT - executeQuery(); - 반환 자료형 : ResultSet
				 * DELETE, INSERT, UPDATE - executeUpdate(); - 반환 자료형 : int - 반영된 투플의 갯수
				 */
				
				ResultSet rs = pstmt.executeQuery(); // SELECT 할 때 사용, executeUpdate() - DELETE, INSERT, UPDATE 추가, 삭제 등에 사용
				while(rs.next()) {
					list.add(new Board(rs));
				}
				
			
		}catch(SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return list;
	}
}
