package com.exception;

public class WonseokLoginException extends Exception {
	public WonseokLoginException(String message) {
		super(message);
	}
}
