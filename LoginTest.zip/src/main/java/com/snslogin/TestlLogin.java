package com.snslogin;

import javax.servlet.http.HttpServletRequest;

import java.net.*;
import java.io.*;
import java.util.*;

import com.exception.*;

import org.json.simple.parser.*;
import org.json.simple.*;

public abstract class TestlLogin {
	public abstract String getCodeURL(HttpServletRequest request);
	public abstract String getAccessToken(HttpServletRequest request) throws WonseokLoginException, IOException, ParseException;
	public abstract String getAccessToken(HttpServletRequest request, String code, String state) throws WonseokLoginException, IOException, ParseException;
	public abstract HashMap<String, String> getUserProfile(String accessToken);
	public JSONObject httpRequest(String apiUrl) throws IOException, ParseException{
		return httpRequest(apiUrl, null);
	}
	
	public JSONObject httpRequest(String apiUrl, HashMap<String, String> headers) throws IOException, ParseException {
		URL url = new URL(apiUrl);
		HttpURLConnection conn = (HttpURLConnection)url.openConnection();
		conn.setRequestMethod("GET");
		if(headers != null ) {
			Iterator<String> ir = headers.keySet().iterator();
			while(ir.hasNext()) { 
				String key = ir.next();
				String value = headers.get(key);
				conn.setRequestProperty(key, value);
			}
		}
		
		int statusCode = conn.getResponseCode();
		InputStream in; 
		if (statusCode == HttpURLConnection.HTTP_OK) {
			in = conn.getInputStream();
		} else { 
			in = conn.getErrorStream();
		}
		
		InputStreamReader isr = new InputStreamReader(in);
		BufferedReader br = new BufferedReader(isr);
		StringBuilder sb = new StringBuilder();
		String line;
		while((line = br.readLine()) != null) {
			sb.append(line);
		}
		br.close();
		isr.close();
		in.close();
		JSONObject json = (JSONObject)new JSONParser().parse(sb.toString());
		return json;
	}
}





