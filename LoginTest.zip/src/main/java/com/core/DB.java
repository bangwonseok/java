package com.core;

import java.sql.*;
import javax.servlet.FilterConfig;

public class DB {
	private static String driver;
	private static String id;
	private static String pass;
	private static String url;
	
	public static void init(FilterConfig config) {
		init(
				config.getInitParameter("Driver"),
				config.getInitParameter("Id"),
				config.getInitParameter("Pass"),
				config.getInitParameter("Url")
		);
	}
	
	public static void init(String driver, String id, String pass, String url){
		DB.driver = driver;
		DB.id = id;
		DB.pass = pass;
		DB.url = url;
	}
		
	public static Connection getConnection()throws ClassNotFoundException, SQLException{
		Class.forName(driver);
		Connection testc = DriverManager.getConnection(id, pass, url);
		return testc;
	}
}
