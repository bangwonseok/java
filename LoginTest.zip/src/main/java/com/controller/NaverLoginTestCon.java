package com.controller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

import com.snslogin.*;
import com.exception.*;

public class NaverLoginTestCon extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out = response.getWriter();
		NaverLoginWS naver = new NaverLoginWS();
		try {
			String asccessToken = naver.getAccessToken(request);
			HashMap<String, String> userInfo = naver.getUserProfile(asccessToken);
			Iterator<String> ir = userInfo.keySet().iterator();
			while(ir.hasNext()) {
				String bws = ir.next();
				String vue = userInfo.get(bws);
				out.printf("%s = %s <br>", bws, vue);
			}
		} catch (Exception e) {
			out.printf("<script>alert('%s');</script>", e.getMessage());
		}
	}
}